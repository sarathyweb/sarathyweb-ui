<?php


include("auth.php"); //include auth.php file on all secure pages ?>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">GPS TRACKER</a>
    </div>
  </div>
</nav>
<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<meta charset="utf-8">
<title>Welcome Home</title>
</head>
<body>
<div class="form">
<p>Welcome <?php echo $_SESSION['username']; ?>...Your Registered Locations are</p>


    
    <?php
    
      include_once('./CMSnews.php');
      $obj = new CMSnews();
	  
	  	 
	if(!isset($_GET['admin'])){
			$_GET['admin']=0;
			
			if( $_GET['admin'] == 0 ){
			echo"
<table class='table'>
        <thead>
            <tr>
<th>S.NO</th>
                <th>Username</th>
            <th>Date and Time</th>
<th>Latitude</th>
<th>Longitude</th>
<th>Map</th>

				</tr>
        </thead>
        <tbody>";	 
			 echo $obj->display_public($_SESSION['username']);
			echo"</tbody></table>"; 
			}
			else
			 echo $obj->display_public($_SESSION['username']);
			}
		
	?>
<hr>
	<a href="logout.php"><input type="button" value="Logout" class="btn btn-danger"/></a>


</div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</html>