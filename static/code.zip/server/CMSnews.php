<?php

class CMSnews{
	private $conn ;
  private $host= "localhost";
  private $username="id13330505_locationtrackerdemo";
  private $password="Adwinalex12345;";
  private $table="id13330505_fine_grained";

function __construct() {
		$this->connect();
		
	}
	
  
  
  
  
  
  
  
  
  
  
  
    
  
function display_public() {
  $q = "SELECT * FROM user_coordinates ORDER BY id DESC ";
  $r = mysqli_query($this->conn, $q);
  $entry_display = null;
$k=0;

  if ( $r !== false && mysqli_num_rows($r) > 0 ) {
  

   
    while ( $a = mysqli_fetch_assoc($r) ) {
      $name = stripslashes($a['username']);
      $time = stripslashes($a['time']);
      $lat = stripslashes($a['lat']);
      $lon = stripslashes($a['lon']);

  $k++;
      $entry_display .= <<<ENTRY_DISPLAY


<tr>
<td>$k</td>
<td>
$name
</td>

<td>
$time
</td>
<td>
$lat
</td><td>
$lon
</td>
<td>

<a href="https://www.google.co.in/maps/@$lat,$lon,15z?hl=en" target="_blank">View on map</a>
</td>
</tr>

ENTRY_DISPLAY;

    }

} 



else {
    $entry_display = <<<ENTRY_DISPLAY

  <p>
    No entries....
  </p>

ENTRY_DISPLAY;
  }


  return $entry_display;


}


  
function display_delete(){
	$result=mysqli_query($this->conn, "select id,username,cat,time from driving_behavior ORDER BY id DESC");
	echo ("<form action='{$_SERVER['PHP_SELF']}' method='post'>");
		echo("<table class='table'><thead><tr> <th>Choose Records to Delete</th></tr></thead><tbody>");
	while($row = mysqli_fetch_row($result)) {
	$id=$row[0];
	$username=$row[1];
	$cat=$row[2];	

	echo "<tr><td><input type='radio' name='option'  value=$id>&nbsp;&nbsp; $username, Category= $cat</input></td></tr>";
	}
	
	return <<<ADMIN_FORM1
   </tbody></table>
      <input type="submit" name="delete" class='bttn'  value="Delete This Entry!" id="delete"/>
    </form>
	
    <br />
    
    <a href="./index.php">Back to Home</a>

ADMIN_FORM1;
  }
  
function delete($p){
  if (isset($_POST['option']))
  {
	$id=$_POST['option'];
	$sql="DELETE from driving_behavior WHERE id=$id";
	return mysqli_query($this->conn, $sql);

  }
  }

 function connect() {
  $this->conn = mysqli_connect($this->host,$this->username,$this->password);
  mysqli_select_db($this->conn, $this->table) or die("Could not select database. " . mysql_error());

 }
 function runQuery($query) {
		$result = mysqli_query($this->conn, $query);
		while($row=mysqli_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}

	
	

}


?>