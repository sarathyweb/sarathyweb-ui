<?php
include("auth.php"); //include auth.php file on all secure pages ?>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">GPS TRACKER</a>
    </div>
	 <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
   <li><a href="../registration.php">Register new user</a></li>
      
   <li><a href="update.php">Manage User Profile</a></li>
    </ul>
	
  </div>
</nav>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<title>Welcome Home</title>
</head>
<body>
<div class="form">
<hr>
<h1 style="text-align:center;text-transform:uppercase"> ALL DB DATA</h1>
<hr>
<br>
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>

<br>
    
    <?php
    
      include_once('./CMSnews.php');
      $obj = new CMSnews();
	  
	  	 
    if(isset($_POST['delete']))
		$obj->delete($_POST['delete']);
	if(!isset($_GET['admin'])){
			$_GET['admin']=0;
			
			if( $_GET['admin'] == 0 ){
			echo"
<table class='table'>
<thead>
<tr>
<th>S.NO</th>
    <th>Username</th>
<th>Date and Time</th>
<th>Latitude</th>
<th>Longitude</th>
<th>Map</th>

</tr>
</thead>
<tbody>";	 
			 echo $obj->display_public();
			echo"</tbody></table>"; 
			echo "
   <a href='{$_SERVER['PHP_SELF']}?admin=2'><input type='button' value='Delete Entry' class='btn btn-danger'/></a>
";
			
			}
			else
			 echo $obj->display_public();
			}
   if($_GET['admin'] == 2){
		 echo ( $_GET['admin'] == 2 ) ? $obj->display_delete() : $obj->display_public();
		}
	?>
<hr>
	<a href="logout.php"><input type="button" value="Logout" class="btn btn-primary"/></a>


</div>
</body>
</html>
