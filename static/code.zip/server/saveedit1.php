<?php
include_once('./CMSnews.php');
      $obj = new CMSnews();
$result = mysql_query("UPDATE user set username= '".$_POST["editval"]."' WHERE  id=".$_POST["id"]);
?>