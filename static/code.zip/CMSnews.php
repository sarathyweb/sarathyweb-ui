<?php

class CMSnews{
	private $conn ;
  private $host= "localhost";
  private $username="id13330505_locationtrackerdemo";
  private $password="Adwinalex12345;";
  private $table="id13330505_fine_grained";

function __construct() {
		$this->connect();
		
	}
	
  
  
  
  
  
  
  
  
  
  
  
  
function display_public($user) {
    $q = "SELECT * FROM user_coordinates WHERE username='$user' ORDER BY id DESC ";
    $r = mysqli_query($this->conn, $q);
		$entry_display = null;
	$k=0;

    if ( $r !== false && mysqli_num_rows($r) > 0 ) {
		

     
      while ( $a = mysqli_fetch_assoc($r) ) {
        $name = stripslashes($a['username']);
        $time = stripslashes($a['time']);
        $lat = stripslashes($a['lat']);
        $lon = stripslashes($a['lon']);

		$k++;
        $entry_display .= <<<ENTRY_DISPLAY

 
	<tr>
<td>$k</td>
<td>
$name
</td>

<td>
$time
</td>
<td>
$lat
</td><td>
$lon
</td>
<td>

<a href="https://www.google.co.in/maps/@$lat,$lon,15z?hl=en" target="_blank">View on map</a>
</td>
</tr>

ENTRY_DISPLAY;

      }

 } 


	
	else {
      $entry_display = <<<ENTRY_DISPLAY

    <p>
      No entries....
    </p>

ENTRY_DISPLAY;
    }


    return $entry_display;
	

  }

 function connect() {
   $this->conn = mysqli_connect($this->host,$this->username,$this->password);
    mysqli_select_db($this->conn, $this->table) or die("Could not select database. " . mysql_error());

 }

}


?>