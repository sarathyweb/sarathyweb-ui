<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Safe Drive</a>
    </div>
  </div>
</nav>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Register</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_REQUEST['username'])){
		$username = stripslashes($_REQUEST['username']); // removes backslashes
		$username = mysqli_real_escape_string($con,$username); //escapes special characters in a string
		$email = stripslashes($_REQUEST['email']);
		$email = mysqli_real_escape_string($con,$email);
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		
		
		
		$dob = stripslashes($_REQUEST['dob']);
		$dob = mysqli_real_escape_string($con,$dob);
				$address = stripslashes($_REQUEST['address']);
		$address = mysqli_real_escape_string($con,$address);



		$trn_date = date("Y-m-d H:i:s");
        $query = "INSERT into `user` (username, password, email,dob,address, trn_date) VALUES ('$username', '$password', '$email','$dob','$address', '$trn_date')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'><h3>You are registered successfully.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
        }
		else{
			    echo "<div class='form'><h3>Same mobile is already registered or Username already exists.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
        
			
		}
    }else{
?>


<div class="container">
  <div class="row">
  	<div class="col-md-6">
    
          <form class="form-horizontal" action=" " method="post" name="registration">
          <fieldset>
            <div id="legend">
              <legend class=""> User registration</legend>
            </div>


			
			
            <div class="control-group">
              <label class="control-label" for="username">UserName</label>
              <div class="controls">
                <input type="text" name="username" placeholder="User Name" required  class="form-control input-lg">
              </div>
            </div>
         
            <div class="control-group">
              <label class="control-label" for="password">Password</label>
              <div class="controls">
                <input type="text" name="password" placeholder="Password" required  class="form-control input-lg">
              </div>
            </div>
         
 <div class="control-group">
              <label class="control-label" for="username">Email</label>
              <div class="controls">
                <input type="email" name="email" placeholder="Email" required class="form-control input-lg">
              </div>
            </div>
         
 <div class="control-group">
              <label class="control-label" for="username">DOB</label>
              <div class="controls">
                <input type="date" name="dob" placeholder="Date of Birth" required  class="form-control input-lg">
              </div>
            </div>
         
 <div class="control-group">
              <label class="control-label" for="username">Address</label>
              <div class="controls">
<textarea  name="address" placeholder="Address" required class="form-control input-lg">
</textarea>
				</div>
            </div>
         		 
  <hr>
            <div class="control-group">
              <!-- Button -->
              <div class="controls">
                <input type="submit" name="submit" value="Register"  class="btn btn-success"></input>
              </div>
            </div>
          </fieldset>
		  <hr>
<a href="login.php"><input type="button" value="Login" class="btn btn-primary"/></a>

		  </form>
    

    </div> 	</div>
</div>














<?php } ?>
</body>
</html>
