<?php
	require('db.php');
	session_start();
    // If form submitted, insert values into the database.
    if (isset($_POST['username'])){
		
		$username = stripslashes($_REQUEST['username']); // removes backslashes
		$username = mysqli_real_escape_string($con,$username); //escapes special characters in a string
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `user` WHERE username='$username' and password='$password'";
    $result = mysqli_query($con,$query);
    if($result != null){
		  $rows = mysqli_num_rows($result);
        if($rows==1){
			$_SESSION['username'] = $username;
			header("Location: index.php"); // Redirect user to index.php
            }
            
          }else{
				echo "<div class='form'><h3>Username/password is incorrect.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
				}
    }else{
?>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">GPS TRACKER</a>
    </div>
  </div>
</nav>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>


<div class="container">
  <div class="row">
  	<div class="col-md-6">
    
          <form class="form-horizontal" action=" " method="post" name="login">
          <fieldset>
            <div id="legend">
              <legend class="">User Login</legend>
            </div>
            <div class="control-group">
              <label class="control-label" for="username">Username</label>
              <div class="controls">
                <input type="text" name="username" placeholder="Username" required  class="form-control input-lg">
              </div>
            </div>
         
            <div class="control-group">
              <label class="control-label" for="password">Password</label>
              <div class="controls">
                <input type="password" name="password" placeholder="Password" required  class="form-control input-lg">
              </div>
            </div>
         
         
            <div class="control-group">
              <!-- Button -->
              <div class="controls">
                <input name="submit" type="submit" value="Login" class="btn btn-success"></input>
              </div>
            </div>
          </fieldset>
		  <hr>
<a href="registration.php"><input type="button" value="Register" class="btn btn-primary"/></a>

		  </form>
    

    </div> 	</div>
</div>






<?php } ?>


</body>
</html>
