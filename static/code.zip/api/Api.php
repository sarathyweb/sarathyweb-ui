<?php 

	require_once 'DbConnect.php';
	
	$response = array();
	
	if(isset($_GET['apicall'])){
		
		switch($_GET['apicall']){
			
			case 'signup':
				if(isTheseParametersAvailable(array('username','email','password','dob','address'))){
					$username = $_POST['username']; 
					$email = $_POST['email']; 
					$password = $_POST['password'];
					$dob = $_POST['dob']; 
					$address = $_POST['address']; 
					$trn_date = date("Y-m-d H:i:s");

					$stmt = $conn->prepare("SELECT id FROM user WHERE username = ? OR email = ?");
					$stmt->bind_param("ss", $username, $email);
					$stmt->execute();
					$stmt->store_result();
					
					if($stmt->num_rows > 0){
						$response['error'] = true;
						$response['message'] = 'User already registered';
						$stmt->close();
					}else{
						$stmt = $conn->prepare("INSERT into `user` (username, password, email,dob,address, trn_date) VALUES (?,?,?,?,?,?)");
						$stmt->bind_param("ssssss",$username, $password, $email,$dob,$address, $trn_date);

						if($stmt->execute()){
							$stmt = $conn->prepare("SELECT id, id, username, email, dob FROM user WHERE username = ?"); 
							$stmt->bind_param("s",$username);
							$stmt->execute();
							$stmt->bind_result($userid, $id, $username, $email, $dob);
							$stmt->fetch();
							
							$user = array(
								'id'=>$id, 
								'username'=>$username, 
								'email'=>$email,
								'dob'=>$dob
							);
							
							$stmt->close();
							
							$response['error'] = false; 
							$response['message'] = 'User registered successfully'; 
							$response['user'] = $user; 
						}
					}
					
				}else{
					$response['error'] = true; 
					$response['message'] = 'required parameters are not available'; 
				}
				
			break; 
			
			case 'login':
				
				if(isTheseParametersAvailable(array('username', 'password'))){
					
					$username = $_POST['username'];
					$password = $_POST['password']; 
					
					$stmt = $conn->prepare("SELECT id, username, email FROM user WHERE username = ? AND password = ?");
					$stmt->bind_param("ss",$username, $password);
					
					$stmt->execute();
					
					$stmt->store_result();
					
					if($stmt->num_rows > 0){
						
						$stmt->bind_result($id, $username, $email);
						$stmt->fetch();
						
						$user = array(
							'id'=>$id, 
							'username'=>$username, 
							'email'=>$email
						);
						
						$response['error'] = false; 
						$response['message'] = 'Login successfull'; 
						$response['user'] = $user; 
					}else{
						$response['error'] = false; 
						$response['message'] = 'Invalid username or password';
					}
				}
			break; 
			
			case 'data':
				
			if(isTheseParametersAvailable(array('username', 'email', 'latitude', 'longitude', 'timestamp','deviceId'))){
			    
				$username = $_POST['username'];
				$email = $_POST['email']; 
				$latitude = $_POST['latitude']; 
				$longitude = $_POST['longitude'];
				$timestamp = $_POST['timestamp'];
				$deviceId = $_POST['deviceId'];

				$splittedLatitude = explode('~',$latitude);
				$splittedLongitude = explode('~',$longitude);
				$splittedTimestamp = explode('~',$timestamp);
				
				$lengthOfBuffer = count($splittedLatitude);

				if($lengthOfBuffer < 1){
					$stmt = $conn->prepare("INSERT INTO user_coordinates(username, email, time, lat, lon, deviceId) VALUES (?,?,?,?,?,?)");
					$stmt->bind_param("ssssss",$username, $email, $timestamp,  $latitude, $longitude,  $deviceId);
				}else{
					for ($index = 0; $index < $lengthOfBuffer; $index++) {
						$stmt = $conn->prepare("INSERT INTO user_coordinates(username, email, time, lat, lon, deviceId) VALUES (?,?,?,?,?,?)");
						$stmt->bind_param("ssssss",$username, $email, $splittedTimestamp[$index],  $splittedLatitude[$index], $splittedLongitude[$index],  $deviceId);					
						$stmt->execute();
					}
				}

				$response['message'] = 'Success';
			}
			break; 


			default: 
				$response['error'] = true; 
				$response['message'] = 'Invalid Operation Called';
		}
		
	}else{
		$response['error'] = true; 
		$response['message'] = 'Invalid API Call';
	}
	
	echo json_encode($response);
	
	function isTheseParametersAvailable($params){
		
		foreach($params as $param){
			if(!isset($_POST[$param])){
				return false; 
			}
		}
		return true; 
	}